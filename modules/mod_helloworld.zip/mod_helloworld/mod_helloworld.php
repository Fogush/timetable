<?php
echo "Hello Joomla!";